# GREWordScrapper
A  scrapper for gre word meaning from merriam-webster dictionary
